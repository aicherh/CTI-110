# This program calculates and displays travel expenses
# September 21, 2022
# CTI-110 P1HW2 - Travel Expense
# Heather Aicher
#

#Create variable and get user input for budget, travel destination, gas, accomodation and food.
#Use int for numerical values.
#Add all numerical input to create variable called expenses.
#Subtract expenses from budget.
#Display Travel Expenses page break, location and budget, one line of whitespace, fuel, accomodation and food, one line of whitespace, remaining balance.

#Input
budget = int(input('Enter budget:'))

destination = input('Enter travel destination:')

gas = int(input('Enter how much will be spent on gas:'))

accomodation = int(input('Enter how much will be spent on accomodations:'))

food = int(input('Enter how much will be spent on food:'))


#Process

expenses = gas + accomodation + food

remains = budget - expenses

#Output

print('---------Travel Expenses---------')
print('Location:', destination)
print('Initial Budget:', budget)
print()
print('Fuel:', gas)
print('Accomodation:', accomodation)
print('Food:', food)
print()
print('Remaining Balance:', remains)
