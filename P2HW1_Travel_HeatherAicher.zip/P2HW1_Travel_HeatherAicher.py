# This program calculates and displays travel expenses
# October 10, 2022
# CTI-110 P2HW1 - Travel Expense
# Heather Aicher
#

#Create variable and get user input for budget, travel destination, gas, accomodation and food.
#Use int for numerical values.
#Add all numerical input to create variable called expenses.
#Subtract expenses from budget.
#Display Travel Expenses page break, location and budget, one line of whitespace, fuel, accomodation and food, one line of whitespace, remaining balance.

#Input
budget = int(input('Enter budget:'))

destination = input('Enter travel destination:')

gas = int(input('Enter how much will be spent on gas:'))

accomodation = int(input('Enter how much will be spent on accomodations:'))

food = int(input('Enter how much will be spent on food:'))


#Process

expenses = gas + accomodation + food

remains = budget - expenses

#Output

print()
print('---------Travel Expenses---------')
print('Location:          ', destination)
print('Initial Budget:    ', f'${budget:.2f}')
print('Fuel:              ', f'${gas:.2f}')
print('Accomodation:      ', f'${accomodation:.2f}')
print('Food:              ', f'${food:.2f}')
print('---------------------------------')
print()
print('Remaining Balance: ', f'${remains:.2f}')

#Code edited from original to line up travel expense output neatly, convert to float and add dollar sign.
