# CTI-110
# P2HW2 - List
# Heather Aicher 
# October 17, 2022
#

# Store test grades for Modules 1-6 via user input in
#a list and display the lowest grade, the highest grade,
#the sum of all grades entered and the grades' average


#Input

grades = []

grades.append(float(input('Enter grade for Module 1:')))
grades.append(float(input('Enter grade for Module 2:')))
grades.append(float(input('Enter grade for Module 3:')))
grades.append(float(input('Enter grade for Module 4:')))
grades.append(float(input('Enter grade for Module 5:')))
grades.append(float(input('Enter grade for Module 6:')))

#Process

#Output

print()
print('------------Results------------')
print('Lowest grade:       ' , min(grades))
print('Highest grade:      ' , max(grades))
print('Sum of grades:      ' , sum(grades))
print('Average:            ' ,(f'{sum(grades)/len(grades):.2f}'))
