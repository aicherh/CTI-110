''' Type your code here. '''
miles_per_gallon = float(input())
dollars_per_gallon = float(input())

dollars_per_mile = dollars_per_gallon * 1/miles_per_gallon

miles_1 = 20 * dollars_per_mile
miles_2 = 75 * dollars_per_mile
miles_3 = 500 * dollars_per_mile

print(f'{miles_1:.2f} {miles_2:.2f} {miles_3:.2f}')
