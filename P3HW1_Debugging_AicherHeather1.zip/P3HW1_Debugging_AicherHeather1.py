# CTI-110
# P3HW1 - Debugging
# Aicher
# October 26, 2022

# Aske for user input for modules 1-6
# Display lowest grade
# Display highest grade
# Display sum of grades
# Diplay average of grades
# Display letter grade based on average grade


grades = []

grades.append(float(input('Enter grade for Module 1:')))
grades.append(float(input('Enter grade for Module 2:')))
grades.append(float(input('Enter grade for Module 3:')))
grades.append(float(input('Enter grade for Module 4:')))
grades.append(float(input('Enter grade for Module 5:')))
grades.append(float(input('Enter grade for Module 6:')))



print()
print('------------Results------------')
print('Lowest grade:       ' , min(grades))
print('Highest grade:      ' , max(grades))
print('Sum of grades:      ' , sum(grades))
print('Average:            ' ,(f'{sum(grades)/len(grades):.2f}'))
print('-------------------------------')



grade_avg = (f'{sum(grades)/len(grades):.2f}')

if grade_avg >= '90':
 print('Your grade is: A')
else:
 if grade_avg >= '80':
  print('Your grade is: B')
 else:
  if grade_avg >= '70':
   print('Your grade is: C')
  else:
    if grade_avg >= '60':
     print('Your grade is: D')
    else:
      if grade_avg <= '59':
       print ('Your grade is: F')   







