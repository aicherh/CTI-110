# CTI-110
# P3HW2 - Salary
# Heather Aicher
# October 31. 2022

# Asks the user to name of employee
# Ask user to enter number of hours the employee worked this month
# Ask user to enter employee's pay rate
# Evaluate if employee has worked overtime. If yes calcuate amount owed to employee for overtime hours
# Calculate amount employee shoud be paid for regular hours worked.
# Display gross pay (total amount that should be paid to employee)
# The program is to display the following: Employee name, pay rate, number of hours worked, overtime hours, overtime pay , pay for regular hours and gross pay).

name = input('Enter Employee\'s name: ')
hours_worked = float(input('Enter number of hours worked: '))
pay_rate = float(input('Enter employee\'s pay rate: '))
print('-----------------------------------------')

print('Employee name: ', name)
print(' ')

ot_hours = (0)
ot_pay = (0)
reg_hours = (0)
reg_pay = (0)

if hours_worked <= 40:
    reg_pay = hours_worked * pay_rate
else: 
    ot_hours = hours_worked - 40
    ot_pay = (pay_rate * 1.5) * ot_hours
    
reg_pay = (hours_worked - ot_hours) * pay_rate

gross_pay = reg_pay + ot_pay
    

print('Hours Worked    Pay Rate    OverTime    OverTime Pay    RegHour Pay    Gross Pay')
print('-------------------------------------------------------------------------------')
print(f'{hours_worked}          {pay_rate}         {ot_hours}       {ot_pay}      {reg_pay}      {gross_pay}')
