# CTI-110
# P4HW1 - Score List
# Heather Aicher 
# November 14, 2022

# Program to collect scores from user and display lowest score,
# average and letter grade


# Ask user to enter number of scores they would like to enter
num_scores = int(input('How many scores do you want to enter? '))
print()

score_list = []
# Create a loop to collect the number of scores the user wants to enter
for i in range(1, num_scores +1):
    score = int(input('Enter score #{}: '.format(i)))
# Evaluate if the score is valid, it should be between 0 and 100    
    if score >= 0 and score <=100:
        score_list.append(score)
# If it is not, notify the user and ask for a VALID score to be entered
# If score is valid, add the score to a list        
    else:
        print('INVALID Score entered!!!! \nScore should be between 0 and 100')
        s = int(input("Enter score #"+str(i)+" again: "))
print()
print('-------------Results-----------')
# Lowest score entered
print('Lowest Score:' , min(score_list))
min_score = min(score_list)
# Drop lowest score
score_list.remove(min_score)
# Modified list after dropping lowest score
print('Modified List:' , (score_list))
sum_scores = sum(score_list)
# The average of scores in modified list
print('Scores Average:', (f'{sum(score_list)/len(score_list):.2f}'))

avg_score = (f'{sum(score_list)/len(score_list):.2f}')
# Determine the letter grade for the calculated average and display it to user
if avg_score  >= '90':
 print('Your grade is: A')
else:
 if avg_score >= '80':
  print('Your grade is: B')
 else:
  if avg_score >= '70':
   print('Your grade is: C')
  else:
    if avg_score >= '60':
     print('Your grade is: D')
    else:
      if avg_score <= '59':
       print ('Your grade is: F')  

                 
                 
