# CTI-110
# P4HW2 - Salary Calculator
# Heather Aicher
# November 16, 2022

# Asks the user employee name
# Enter user pay rate and hours worked
# Calculate overpay and regPay. Store these values in variables,
# at the end of the program you will display overtime total, regular pay total,
# gross pay total and number of employees entered
# Ask user to enter another employee's name to calculate salary for or "None" to terminate program.
# Note we are using sentinals here.
# When user chooses to stop entering employee information , display results as shown in image below.
# THE PROGRAM ONLY TERMINATES IF THE USERS "None" for employee name.

num_employees = 0
totalot_pay = 0
totalreg_pay = 0
totalgross_pay = 0

while True:
    name = input('Enter employee\'s name or \"None\" to terminate: ')
    if name == "None":
        break
    else:
        num_employees += 1

    hours_worked = float(input('Enter number of hours ' + name + ' worked: '))
    pay_rate = float(input('Enter ' + name + '\'s pay rate: '))

    ot_hours = 0
    ot_pay = 0
    reg_pay = 0
    gross_pay = 0

    if hours_worked > 40:
        ot_hours = hours_worked - 40
        ot_pay = ot_hours * pay_rate * 1.5
        reg_pay = pay_rate * 40
        gross_pay = reg_pay + ot_pay
    else:
        reg_pay = hours_worked * pay_rate
        gross_pay = reg_pay

    totalot_pay += ot_pay
    totalreg_pay += reg_pay
    totalgross_pay += gross_pay

    print('\nEmployee name: ' + name + '\n')
    print('{:<20}'.format('Hours Worked'),'{:<20}'.format('Pay Rate'), '{:<20}'.format('OverTime'), '{:<20}'.format('OverTime Pay'), '{:<20}'.format ('RegHour Pay'), '{:<20}'.format('Gross Pay'))
    print('-------------------------------------------------------------------------------------------------------------------------------------')
    print('{:<20.2f}'.format(hours_worked), '${:<20.2f}'.format(pay_rate),'{:<20.2f}'.format(ot_hours), '${:<20.2f}'.format(ot_pay), '${:<20.2f}'.format(reg_pay), '${:<20.2f}'.format(gross_pay))
    print()

print()
print("Total number of employees entered:", num_employees)
print("Total amount paid for over time: $" + '{:.2f}'.format(totalot_pay))
print("Total amount paid for regular hours: $" + '{:.2f}'.format(totalreg_pay))
print("Total amount paid in gross: $" + '{:.2f}'.format(totalgross_pay))



