# CTI 110
# P4Lab1 - Output Range
# November 9, 2022
# Heather Aicher

# Write a program whose input is two integers.
# Output the first integer and subsequent increments of 5 as long as
# the value is less than or equal to the second integer.
# Output a space after every integer, including the last.


num_1 = int(input())
num_2 = int(input())

if num_1 <= num_2:
    while num_1 <= num_2:
        print(num_1, end=' ')
        num_1 += 5
else:
    print('Second integer can\'t be less than the first.')
