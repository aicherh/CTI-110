
# CTI 110
# P5HW - Math Quiz
# Heather Aicher
# November 28, 2022

# Menu driven math quiz program
# When/if user enters 1, the program is to execute a function that
# generates the numbers, adds them, asks user to enter an answer and
# display results.
# When/if user enters 2, the program is to execute a function that
# generates the numbers, subtracts them, asks user to enter an answer
# and display results.
# If/when the user enters 3, the program is to terminate.
# If/when user enters anything other than 1, 2, or 3, an error message
# should display letting the user know, then the menu should display again.
# When/if user guesses the right number, congratulate them and display
# the menu again to give them the option to play again

import add

import sub


print('Welcome to Math Quiz')
print('')

exit_program = False

while exit_program == False:
    print('MAIN MENU')
    print('-----------------------')
    print('1. Adding Random Numbers')
    print('2. Subtracting Random Numbers')
    print('3. Exit')
    print('')
    choice = input('Please choose one of the menu options: ')

    if choice == '1':
        add.add_numbers()
    elif choice == '2':
        sub.sub_numbers()
    elif choice == '3':
        print('Thank you for playing.')
        print('Bye.')
        exit_program = True
        
    else:
        print('Invalid. Please choose one of the menu options.')
        
