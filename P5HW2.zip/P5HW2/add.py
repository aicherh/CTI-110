import random

number = random.randint(1, 100)
number_two = random.randint(1, 100)

def add_numbers():
    print(f' {number}')
    print(f'+{number_two}')
    guess_add = int(input('Guess the answer: '))

    count = 1

    while guess_add != number + number_two:
        count += 1
        if guess_add < number + number_two :
            print('Sorry, that is too low.')
        else:
            print('Sorry, that is too high.')
        guess_add = int(input('Try again: '))
    print('Congratulations! Your answer is correct.')
    print('Number of guesses: ', count)

