# CTI 110
# P4LAB2a - Turtle square and triangle
# November, 7 2022
# Heather Aicher

# draw and square and a triangle using loops in turtle

import turtle
win = turtle.Screen()
samantha = turtle.Turtle()

samantha.pensize(4)
samantha.pencolor ("teal")
samantha.shape("turtle")

# square
for i in range(4):
    samantha.forward(50)
    samantha.left(90)

# move
samantha.penup()
samantha.forward(100)
samantha.pendown()

# triangle
for i in range(3):
    samantha.forward(100)
    samantha.left(120)

win.mainloop()





