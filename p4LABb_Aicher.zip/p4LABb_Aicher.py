# CTI 110
# P4LAB2b - Initials
# November, 7 2022
# Heather Aicher

# draw initials with turtle using loops

import turtle
win = turtle.Screen()
agnes = turtle.Turtle()

agnes.pensize(7)
agnes.pencolor ("purple")
agnes.shape("turtle")

# position
agnes.penup()
agnes.back(200)
agnes.pendown()
agnes.left(90)

# H
agnes.forward(180)
agnes.backward(90)
agnes.right(90)
agnes.forward(90)
agnes.left(90)
agnes.forward(90)
agnes.backward(180)

# position
agnes.right(90)
agnes.penup()
agnes.forward(90)
agnes.pendown()
agnes.left(65)

# A
agnes.forward(180)
agnes.backward(90)
agnes.right(65)
agnes.forward(65)
agnes.left(110)
agnes.forward(80)
agnes.right(180)
agnes.forward(170)

# position
agnes.penup()
agnes.forward(50)
agnes.pendown()

# circle for looping
for i in range(360):
    agnes.forward(1)
    agnes.left(1)

win.mainloop()
