# CTI 110
# P4LAB2c - Snowflake
# November, 7 2022
# Heather Aicher

# use range function to draw snowflake

import turtle
win = turtle.Screen()
winona = turtle.Turtle()

winona.pensize(3)
winona.pencolor ("blue")
winona.shape("turtle")

for i in range(12):
    winona.left(90)
    winona.forward(100)
    winona.backward(40)
    winona.left(40)
    winona.forward(30)
    winona.backward(30)
    winona.right(80)
    winona.forward(30)
    winona.backward(30)
    winona.left(40)
    winona.backward(60)
    winona.right(60)




